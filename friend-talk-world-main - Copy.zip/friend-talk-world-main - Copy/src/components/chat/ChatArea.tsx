import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Send, Bell } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { EmojiPicker } from './EmojiPicker';
import { MessageTypeSelector } from './MessageTypeSelector';
import { CallControls } from './CallControls';
import { useTheme } from '@/contexts/ThemeContext';

interface Message {
  id: string;
  content: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  timestamp: string;
  type: 'text' | 'image' | 'code' | 'file';
}

interface ChatAreaProps {
  selectedChat: string | null;
}


const chatMessages: Record<string, Message[]> = {
  '1': [
    {
      id: '1',
      content: 'Hey! How are you doing?',
      senderId: '2',
      senderName: 'Gaurav Gupta',
      senderAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Gaurav',
      timestamp: '10:30 AM',
      type: 'text'
    },
    {
      id: '2',
      content: "I'm doing great! Just working on some new features for our chat app. 🚀",
      senderId: '1',
      senderName: 'You',
      senderAvatar: '',
      timestamp: '10:32 AM',
      type: 'text'
    },
    {
      id: '3',
      content: `function sendMessage(content) {\n  const message = {\n    id: Date.now(),\n    content,\n    timestamp: new Date()\n  };\n  socket.emit('message', message);\n}`,
      senderId: '1',
      senderName: 'You',
      senderAvatar: '',
      timestamp: '10:35 AM',
      type: 'code'
    },
    {
      id: '4',
      content: 'That looks great! The code structure is really clean 👍',
      senderId: '2',
      senderName: 'Gaurav Gupta',
      senderAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Gaurav',
      timestamp: '10:36 AM',
      type: 'text'
    }
  ],
  // Other chats unchanged...
  '2': [ /* Same as before */ ],
  '3': [ /* Same as before */ ],
  '4': [ /* Same as before */ ],
  '5': [ /* Same as before */ ]
};

// Update chat names
const chatNames: Record<string, string> = {
  '1': 'Gaurav Gupta',
  '2': 'Development Team',
  '3': 'liza',
  '4': 'Design Squad',
  '5': 'Marketing Group'
};

export const ChatArea = ({ selectedChat }: ChatAreaProps) => {
  const { user } = useAuth();
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [messageType, setMessageType] = useState<'text' | 'image' | 'code'>('text');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  let currentTheme = { colors: 'from-blue-500 to-purple-600' };
  try {
    const { theme, themes } = useTheme();
    currentTheme = themes.find(t => t.name === theme) || themes[0];
  } catch (error) {
    console.warn('Theme context not available, using fallback');
  }

  useEffect(() => {
    if (selectedChat && chatMessages[selectedChat]) {
      const chatMessageList = chatMessages[selectedChat].map(msg => ({
        ...msg,
        senderId: msg.senderId === '1' ? (user?.id || '1') : msg.senderId,
        senderName: msg.senderName === 'You' ? (user?.name || 'You') : msg.senderName,
        senderAvatar: msg.senderId === '1' ? (user?.avatar || '') : msg.senderAvatar
      }));
      setMessages(chatMessageList);
    } else if (selectedChat) {
      setMessages([]);
    }
  }, [selectedChat, user]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !selectedChat || !user) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      content: message,
      senderId: user.id,
      senderName: user.name,
      senderAvatar: user.avatar || '',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: messageType
    };

    setMessages(prev => [...prev, newMessage]);
    setMessage('');
    setMessageType('text');

    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const response: Message = {
        id: (Date.now() + 1).toString(),
        content: "Thanks for the message! This is a demo response.",
        senderId: '2',
        senderName: chatNames[selectedChat] || 'Chat Member',
        senderAvatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${chatNames[selectedChat] || 'Member'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: 'text'
      };
      setMessages(prev => [...prev, response]);
    }, 2000);
  };

  const handleEmojiSelect = (emoji: string) => {
    setMessage(prev => prev + emoji);
  };

  const handleStartCall = (type: 'voice' | 'video') => {
    console.log(`Starting ${type} call`);
  };

  const renderMessage = (msg: Message) => {
    const isOwn = msg.senderId === user?.id;

    return (
      <div key={msg.id} className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}>
        <div className={`flex items-end space-x-2 max-w-xs lg:max-w-md ${isOwn ? 'flex-row-reverse space-x-reverse' : ''}`}>
          <Avatar className="w-6 h-6">
            <AvatarImage src={msg.senderAvatar} />
            <AvatarFallback className="text-xs">{msg.senderName[0]}</AvatarFallback>
          </Avatar>
          <div className={`px-4 py-2 rounded-2xl ${isOwn ? `bg-gradient-to-r ${currentTheme.colors} text-white` : 'bg-white text-gray-900 border border-gray-200'}`}>
            {msg.type === 'code' ? (
              <pre className={`text-sm font-mono whitespace-pre-wrap ${isOwn ? 'text-gray-100' : 'text-gray-800'}`}>
                <code>{msg.content}</code>
              </pre>
            ) : (
              <p className="text-sm">{msg.content}</p>
            )}
            <p className={`text-xs mt-1 ${isOwn ? 'text-opacity-80 text-white' : 'text-gray-500'}`}>{msg.timestamp}</p>
          </div>
        </div>
      </div>
    );
  };

  if (!selectedChat) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className={`w-16 h-16 bg-gradient-to-r ${currentTheme.colors} rounded-full flex items-center justify-center mx-auto mb-4`}>
            <Bell className="h-8 w-8 text-white" />
          </div>
          <h3 className="text-xl font-semibold text-gray-700 mb-2">Welcome to ChatApp</h3>
          <p className="text-gray-500">Select a conversation to start chatting</p>
        </div>
      </div>
    );
  }

  const currentChatName = chatNames[selectedChat] || 'Unknown Chat';

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      {/* Chat Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar>
              <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${currentChatName}`} />
              <AvatarFallback>{currentChatName[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold text-gray-900">{currentChatName}</h3>
              <p className="text-sm text-green-600">Online</p>
            </div>
          </div>
          <CallControls onStartCall={handleStartCall} />
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-500">
            <p>No messages yet. Start the conversation!</p>
          </div>
        ) : (
          messages.map(renderMessage)
        )}

        {isTyping && (
          <div className="flex justify-start">
            <div className="flex items-end space-x-2 max-w-xs lg:max-w-md">
              <Avatar className="w-6 h-6">
                <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${currentChatName}`} />
                <AvatarFallback className="text-xs">{currentChatName[0]}</AvatarFallback>
              </Avatar>
              <div className="bg-white text-gray-900 border border-gray-200 px-4 py-2 rounded-2xl">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white border-t border-gray-200 p-4">
        {messageType === 'code' && (
          <div className="mb-2">
            <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">Code snippet mode</span>
          </div>
        )}
        <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
          <div className="flex-1 relative">
            {messageType === 'code' ? (
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type your code..."
                className="w-full p-3 border border-gray-300 rounded-lg font-mono text-sm resize-none"
                rows={3}
              />
            ) : (
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type a message..."
                className="pr-24"
              />
            )}
            <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex space-x-1">
              <MessageTypeSelector onTypeSelect={setMessageType} />
              <EmojiPicker onEmojiSelect={handleEmojiSelect} />
            </div>
          </div>
          <Button type="submit" className={`bg-gradient-to-r ${currentTheme.colors} hover:opacity-90`} disabled={!message.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  );
};
