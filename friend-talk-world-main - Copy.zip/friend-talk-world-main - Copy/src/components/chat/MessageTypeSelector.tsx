
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Code, Image, Type } from 'lucide-react';

interface MessageTypeSelectorProps {
  onTypeSelect: (type: 'text' | 'image' | 'code') => void;
}

export const MessageTypeSelector = ({ onTypeSelect }: MessageTypeSelectorProps) => {
  const [open, setOpen] = useState(false);

  const messageTypes = [
    { type: 'text' as const, label: 'Text', icon: Type },
    { type: 'image' as const, label: 'Image', icon: Image },
    { type: 'code' as const, label: 'Code', icon: Code }
  ];

  const handleTypeSelect = (type: 'text' | 'image' | 'code') => {
    onTypeSelect(type);
    setOpen(false);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button type="button" variant="ghost" size="sm">
          <Type className="h-4 w-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-48 p-2">
        <div className="space-y-1">
          {messageTypes.map((messageType) => (
            <Button
              key={messageType.type}
              variant="ghost"
              size="sm"
              className="w-full justify-start"
              onClick={() => handleTypeSelect(messageType.type)}
            >
              <messageType.icon className="h-4 w-4 mr-2" />
              {messageType.label}
            </Button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
};
