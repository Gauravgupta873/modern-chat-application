
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Palette } from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';

export const ThemeSwitcher = () => {
  const { theme, setTheme, themes } = useTheme();
  const [open, setOpen] = useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm">
          <Palette className="h-4 w-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-4">
        <h3 className="font-semibold mb-3">Choose Theme</h3>
        <div className="grid grid-cols-2 gap-2">
          {themes.map((themeOption) => (
            <Button
              key={themeOption.name}
              variant={theme === themeOption.name ? "default" : "outline"}
              size="sm"
              onClick={() => {
                setTheme(themeOption.name);
                setOpen(false);
              }}
              className="justify-start"
            >
              <div className={`w-4 h-4 rounded-full bg-gradient-to-r ${themeOption.colors} mr-2`} />
              {themeOption.label}
            </Button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
};
