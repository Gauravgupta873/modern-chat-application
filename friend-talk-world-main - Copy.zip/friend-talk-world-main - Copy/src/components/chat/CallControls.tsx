
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Video, VideoOff, Mic, MicOff } from 'lucide-react';

interface CallControlsProps {
  onStartCall: (type: 'voice' | 'video') => void;
}

export const CallControls = ({ onStartCall }: CallControlsProps) => {
  const [open, setOpen] = useState(false);
  const [isInCall, setIsInCall] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isMicOn, setIsMicOn] = useState(true);

  const handleStartCall = (type: 'voice' | 'video') => {
    onStartCall(type);
    setIsInCall(true);
    setOpen(false);
    console.log(`Starting ${type} call`);
  };

  const handleEndCall = () => {
    setIsInCall(false);
    console.log('Call ended');
  };

  if (isInCall) {
    return (
      <div className="flex items-center space-x-2 bg-gray-100 rounded-lg p-2">
        <Button
          variant={isMicOn ? "default" : "destructive"}
          size="sm"
          onClick={() => setIsMicOn(!isMicOn)}
        >
          {isMicOn ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
        </Button>
        <Button
          variant={isVideoOn ? "default" : "destructive"}
          size="sm"
          onClick={() => setIsVideoOn(!isVideoOn)}
        >
          {isVideoOn ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}
        </Button>
        <Button variant="destructive" size="sm" onClick={handleEndCall}>
          End Call
        </Button>
      </div>
    );
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm">
          <Video className="h-4 w-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-40 p-2">
        <div className="space-y-2">
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start"
            onClick={() => handleStartCall('voice')}
          >
            <Mic className="h-4 w-4 mr-2" />
            Voice Call
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start"
            onClick={() => handleStartCall('video')}
          >
            <Video className="h-4 w-4 mr-2" />
            Video Call
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
};
