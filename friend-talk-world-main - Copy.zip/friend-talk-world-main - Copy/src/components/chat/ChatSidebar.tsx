import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Settings, User, Users, Search, Bell, Plus } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { ProfileSettings } from './ProfileSettings';
import { ThemeSwitcher } from './ThemeSwitcher';
import { useTheme } from '@/contexts/ThemeContext';

interface Chat {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  timestamp: string;
  unreadCount: number;
  isGroup: boolean;
  isOnline?: boolean;
  memberCount?: number;
}

interface ChatSidebarProps {
  selectedChat: string | null;
  onSelectChat: (chatId: string) => void;
}

export const ChatSidebar = ({ selectedChat, onSelectChat }: ChatSidebarProps) => {
  const { user, logout } = useAuth();
  const { theme, themes } = useTheme();
  const [showSettings, setShowSettings] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [chatFilter, setChatFilter] = useState<'all' | 'private' | 'groups'>('all');

  const currentTheme = themes.find(t => t.name === theme) || themes[0];

  const chats: Chat[] = [
    {
      id: '1',
      name: 'gaurav gupta',
      avatar: 'https://api.dicebear.com/7.x/fun-emoji/svg?seed=gaurav',
      lastMessage: 'Hey! How are you doing?',
      timestamp: '2 min ago',
      unreadCount: 2,
      isGroup: false,
      isOnline: true
    },
    {
      id: '2',
      name: 'Development Team',
      avatar: 'https://api.dicebear.com/7.x/icons/svg?seed=devteam',
      lastMessage: 'Sprint planning meeting at 3 PM',
      timestamp: '1 hour ago',
      unreadCount: 5,
      isGroup: true,
      memberCount: 8
    },
    {
      id: '3',
      name: 'liza',
      avatar: 'https://api.dicebear.com/7.x/fun-emoji/svg?seed=liza',
      lastMessage: 'Thanks for the help!',
      timestamp: 'Yesterday',
      unreadCount: 0,
      isGroup: false,
      isOnline: false
    },
    {
      id: '4',
      name: 'Design Squad',
      avatar: 'https://api.dicebear.com/7.x/shapes/svg?seed=design',
      lastMessage: 'New mockups are ready for review',
      timestamp: '2 hours ago',
      unreadCount: 3,
      isGroup: true,
      memberCount: 5
    },
    {
      id: '5',
      name: 'Marketing Group',
      avatar: 'https://api.dicebear.com/7.x/icons/svg?seed=marketing',
      lastMessage: 'Campaign launch tomorrow!',
      timestamp: '3 hours ago',
      unreadCount: 1,
      isGroup: true,
      memberCount: 12
    }
  ];

  const filteredChats = chats.filter(chat => {
    const matchesSearch = chat.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = 
      chatFilter === 'all' || 
      (chatFilter === 'private' && !chat.isGroup) ||
      (chatFilter === 'groups' && chat.isGroup);
    return matchesSearch && matchesFilter;
  });

  if (showSettings) {
    return <ProfileSettings onClose={() => setShowSettings(false)} />;
  }

  return (
    <div className="w-80 bg-white border-r border-gray-200 flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Avatar>
              <AvatarImage src={user?.avatar} />
              <AvatarFallback>{user?.name?.[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-semibold text-gray-900">{user?.name}</h2>
              <div className="flex items-center space-x-1">
                <div className={`w-2 h-2 bg-gradient-to-r ${currentTheme.colors} rounded-full`}></div>
                <span className="text-xs text-gray-500">Online</span>
              </div>
            </div>
          </div>
          <div className="flex space-x-1">
            <ThemeSwitcher />
            <Button variant="ghost" size="sm" onClick={() => setShowSettings(true)}>
              <Settings className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={logout}>
              <Bell className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Chat Filter Tabs */}
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
          <Button
            variant={chatFilter === 'all' ? 'default' : 'ghost'}
            size="sm"
            className="flex-1 text-xs"
            onClick={() => setChatFilter('all')}
          >
            All
          </Button>
          <Button
            variant={chatFilter === 'private' ? 'default' : 'ghost'}
            size="sm"
            className="flex-1 text-xs"
            onClick={() => setChatFilter('private')}
          >
            <User className="h-3 w-3 mr-1" />
            Private
          </Button>
          <Button
            variant={chatFilter === 'groups' ? 'default' : 'ghost'}
            size="sm"
            className="flex-1 text-xs"
            onClick={() => setChatFilter('groups')}
          >
            <Users className="h-3 w-3 mr-1" />
            Groups
          </Button>
        </div>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto">
        {filteredChats.map((chat) => (
          <div
            key={chat.id}
            onClick={() => onSelectChat(chat.id)}
            className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors ${
              selectedChat === chat.id ? `bg-gradient-to-r ${currentTheme.colors} bg-opacity-10 border-r-2 border-r-current` : ''
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Avatar>
                  <AvatarImage src={chat.avatar} />
                  <AvatarFallback>{chat.name[0]}</AvatarFallback>
                </Avatar>
                {!chat.isGroup && chat.isOnline && (
                  <div className={`absolute bottom-0 right-0 w-3 h-3 bg-gradient-to-r ${currentTheme.colors} border-2 border-white rounded-full`}></div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <h3 className="font-medium text-gray-900 truncate">{chat.name}</h3>
                    {chat.isGroup && (
                      <div className="flex items-center space-x-1">
                        <Users className="h-3 w-3 text-gray-400" />
                        <span className="text-xs text-gray-500">{chat.memberCount}</span>
                      </div>
                    )}
                  </div>
                  <span className="text-xs text-gray-500">{chat.timestamp}</span>
                </div>
                <div className="flex items-center justify-between mt-1">
                  <p className="text-sm text-gray-600 truncate">{chat.lastMessage}</p>
                  {chat.unreadCount > 0 && (
                    <Badge className={`text-xs bg-gradient-to-r ${currentTheme.colors} border-0`}>
                      {chat.unreadCount}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* New Chat Button */}
      <div className="p-4 border-t border-gray-200">
        <Button className={`w-full bg-gradient-to-r ${currentTheme.colors} hover:opacity-90`}>
          <Plus className="h-4 w-4 mr-2" />
          New Chat
        </Button>
      </div>
    </div>
  );
};
