
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Theme = 'default' | 'ocean' | 'sunset' | 'forest' | 'galaxy' | 'coral';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  themes: Array<{ name: Theme; label: string; colors: string }>;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const themes = [
  { 
    name: 'default' as Theme, 
    label: 'Default', 
    colors: 'from-purple-600 to-blue-600' 
  },
  { 
    name: 'ocean' as Theme, 
    label: 'Ocean', 
    colors: 'from-cyan-500 to-blue-500' 
  },
  { 
    name: 'sunset' as Theme, 
    label: 'Sunset', 
    colors: 'from-orange-500 to-pink-500' 
  },
  { 
    name: 'forest' as Theme, 
    label: 'Forest', 
    colors: 'from-green-500 to-emerald-600' 
  },
  { 
    name: 'galaxy' as Theme, 
    label: 'Galaxy', 
    colors: 'from-purple-500 to-indigo-600' 
  },
  { 
    name: 'coral' as Theme, 
    label: 'Coral', 
    colors: 'from-pink-500 to-rose-500' 
  }
];

export const ThemeProvider = ({ children }: { children: ReactNode }) => {
  const [theme, setTheme] = useState<Theme>('default');

  useEffect(() => {
    const savedTheme = localStorage.getItem('chatTheme') as Theme;
    if (savedTheme && themes.find(t => t.name === savedTheme)) {
      setTheme(savedTheme);
    }
  }, []);

  const handleSetTheme = (newTheme: Theme) => {
    setTheme(newTheme);
    localStorage.setItem('chatTheme', newTheme);
    console.log('Theme changed to:', newTheme);
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme: handleSetTheme, themes }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
